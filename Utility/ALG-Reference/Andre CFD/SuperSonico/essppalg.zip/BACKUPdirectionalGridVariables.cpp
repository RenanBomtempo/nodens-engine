//directionalGridVariables.cpp
/* 
   Updates directional values of physical variables (velocity, density, pressure
   and temperature) at each cell due to its neighbors.
*/


#include "Cell.h"
#include "Grid.h"
#include "functions.h"

#include <cstdlib>
#include <cmath>

#include <gl/gl.h>
#include <gl/glut.h>

/*______________________________________________________________________________
	                       
                            FUNCTION setGridVariables()
								
    Traverses the grid, updating the physical variables in each cell 
    for each of its four directions (north, south, east, west). Each direction
    is influenced by all neighboring cells in that direction.
    In order to do this, calls function setCellVariables() for each neighbor.
    It is also called by those functions responsible for solving the Navier-Stokes
    equations and correspondingly updating the physical variables according to
    the solutions found.
    
______________________________________________________________________________*/
void setGridVariables( Grid *grid )
{
    Cell *gridCell,
         *neighborGridCell;
    char direction;
    
    gridCell = grid->firstGridCell;
    while ( gridCell != 0 )
    {
        //Sets all directional physical variables initially to zero, before updating.
        if ( gridCell->active )
        {            
            gridCell->northVelocityX = 0.0;
            gridCell->southVelocityX = 0.0;
            gridCell->eastVelocityX = 0.0;
            gridCell->westVelocityX = 0.0;
            
            gridCell->northVelocityY = 0.0;
            gridCell->southVelocityY = 0.0;
            gridCell->eastVelocityY = 0.0;
            gridCell->westVelocityY = 0.0;            
            
            gridCell->northDensity = 0.0;
            gridCell->southDensity = 0.0;
            gridCell->eastDensity = 0.0;
            gridCell->westDensity = 0.0;
            
            gridCell->northPressure = 0.0;
            gridCell->southPressure = 0.0;
            gridCell->eastPressure = 0.0;
            gridCell->westPressure = 0.0;
            
            gridCell->northTemperature = 0.0;
            gridCell->southTemperature = 0.0;
            gridCell->eastTemperature = 0.0;
            gridCell->westTemperature = 0.0;
        }              
        gridCell = gridCell->next;
    } 
    
    //Updates cell directional physical variables according to each direction.    
    gridCell = grid->firstGridCell;
    while ( gridCell != 0 )
    {
        if ( gridCell->active )
           {
               neighborGridCell = gridCell->south;
               direction = 's';
               setCellVariables( grid, gridCell, neighborGridCell, direction);
               
               neighborGridCell = gridCell->north;
               direction = 'n';
               setCellVariables( grid, gridCell, neighborGridCell, direction);              
               
               neighborGridCell = gridCell->east;
               direction = 'e';
               setCellVariables( grid, gridCell, neighborGridCell, direction);
               
               neighborGridCell = gridCell->west;
               direction = 'w';
               setCellVariables( grid, gridCell, neighborGridCell, direction );
                                             
           }
        gridCell = gridCell->next;
    }
}


/*______________________________________________________________________________
________________________________________________________________________________
 
                            FUNCTION setCellVariables()

     Computes 
         gridCell->northVariable, 
         gridCell->southVariable, 
         gridCell->eastVariable and
         gridCell->westVariable.
     Its arguments are the current gridCell, its neighbor related to which the 
     directional physical variable is going to be computed and the direction of 
     the neighbor relative to gridCell.
     
______________________________________________________________________________*/

void setCellVariables( Grid *grid, Cell *gridCell, Cell *neighborGridCell, char direction )
{
    double weight,
           ratio,
           distance,
           deltaDistance;
    
  	/* If neighborGridCell is a transition node, considers the cell to which its
       doubleConnector1 points to, which will be the new neighborGridCell.
  	   This is repeatedly done until a cell node is found. */
  	if ( neighborGridCell->level > gridCell->level )
    	while( ( neighborGridCell->type == 'w' ) && 
               ( neighborGridCell->singleConnector != 0 ) 
             )
    	{
        	neighborGridCell = neighborGridCell->doubleConnector1;
    	}   	
  	else
    	while( ( neighborGridCell->type == 'w' ) && 
               ( neighborGridCell->singleConnector != 0 ) 
             )
    	{
    		neighborGridCell = neighborGridCell->singleConnector;
   		}
   	
    /* It enters this "if" only if neighborGridCell is connected to null, i.e.,
       only if gridCell belongs to the boundary of the domain. Then it calls
       function set<Direction>BoundaryCellVariables() in order to set the physical
       variables for this cell. */
    if( ( neighborGridCell->type == 'w' ) || ( neighborGridCell->active == false ) )
    {
        if( direction == 's')      
            setSouthBoundaryCellVariables( grid, gridCell );
        else if( direction == 'n' ) 
            setNorthBoundaryCellVariables( gridCell );
        else if( direction == 'e' )
            setEastBoundaryCellVariables( grid, gridCell );
        else if( direction == 'w' )
            setWestBoundaryCellVariables( grid, gridCell );
    }
    //Enters here almost always, except in the case indicated above.  
    else if( ( neighborGridCell->type == 'b' ) && ( neighborGridCell->active == true ) )
    {
        if( (gridCell->level > neighborGridCell->level) || 
            //Avoids computing twice for the same cell.
    		  ( (gridCell->level == neighborGridCell->level) &&
    		  //Follows the dictionary order, to prevent computing the same variable twice.
            	( (gridCell->centerX > neighborGridCell->centerX) ||
           		  ( ( gridCell->centerX == neighborGridCell->centerX ) && 
                              ( gridCell->centerY > neighborGridCell->centerY ) )
                )
              )
            )
        
        {
              weight = 1; //Contribution.
              int i = gridCell->level - neighborGridCell->level; 
              while ( i > 0 )
              {
                weight *= 2;
                i--;
              }
              ratio = 1.0/weight;
              
              deltaDistance = grid->tubeScaleFactor * 
              ( gridCell->halfFaceLength + neighborGridCell->halfFaceLength );
                      
              if( direction == 's')
              {
                  gridCell->southVelocityX += neighborGridCell->currentVelocityX;
                  gridCell->southVelocityY += neighborGridCell->currentVelocityY;
                  gridCell->southPressure += neighborGridCell->currentPressure;
                  gridCell->southDensity += neighborGridCell->currentDensity;
                  gridCell->southTemperature += neighborGridCell->currentTemperature;
                  
                  neighborGridCell->northVelocityX += gridCell->currentVelocityX * ratio;
                  neighborGridCell->northVelocityY += gridCell->currentVelocityY * ratio;
                  neighborGridCell->northPressure += gridCell->currentPressure * ratio;
                  neighborGridCell->northDensity += gridCell->currentDensity * ratio;
                  neighborGridCell->northTemperature += gridCell->currentTemperature * ratio;
              }
              else if( direction == 'n')
              {
                  gridCell->northVelocityX += neighborGridCell->currentVelocityX;
                  gridCell->northVelocityY += neighborGridCell->currentVelocityY;
                  gridCell->northPressure += neighborGridCell->currentPressure;
                  gridCell->northDensity += neighborGridCell->currentDensity;
                  gridCell->northTemperature += neighborGridCell->currentTemperature;
                  
                  neighborGridCell->southVelocityX += gridCell->currentVelocityX * ratio;
                  neighborGridCell->southVelocityY += gridCell->currentVelocityY * ratio;
                  neighborGridCell->southPressure += gridCell->currentPressure * ratio;
                  neighborGridCell->southDensity += gridCell->currentDensity * ratio;
                  neighborGridCell->southTemperature += gridCell->currentTemperature * ratio;
              }
              else if( direction == 'e')
              {
                  gridCell->eastVelocityX += neighborGridCell->currentVelocityX;
                  gridCell->eastVelocityY += neighborGridCell->currentVelocityY;
                  gridCell->eastPressure += neighborGridCell->currentPressure;
                  gridCell->eastDensity += neighborGridCell->currentDensity;
                  gridCell->eastTemperature += neighborGridCell->currentTemperature;
                  
                  neighborGridCell->westVelocityX += gridCell->currentVelocityX * ratio;
                  neighborGridCell->westVelocityY += gridCell->currentVelocityY * ratio;
                  neighborGridCell->westPressure += gridCell->currentPressure * ratio;
                  neighborGridCell->westDensity += gridCell->currentDensity * ratio;
                  neighborGridCell->westTemperature += gridCell->currentTemperature * ratio;
              }
              
              else if( direction == 'w')
              {
                  gridCell->westVelocityX += neighborGridCell->currentVelocityX;
                  gridCell->westVelocityY += neighborGridCell->currentVelocityY;
                  gridCell->westPressure += neighborGridCell->currentPressure;
                  gridCell->westDensity += neighborGridCell->currentDensity;
                  gridCell->westTemperature += neighborGridCell->currentTemperature;
                  
                  neighborGridCell->eastVelocityX += gridCell->currentVelocityX * ratio;
                  neighborGridCell->eastVelocityY += gridCell->currentVelocityY * ratio;
                  neighborGridCell->eastPressure += gridCell->currentPressure * ratio;
                  neighborGridCell->eastDensity += gridCell->currentDensity * ratio;
                  neighborGridCell->eastTemperature += gridCell->currentTemperature * ratio;
              }
                                          
        }
    }
 
}

