/*  ========== solve.cpp =========
    Contem funcoes para resolver as equacoes
    de Navier-Stokes
*/

#include "Cell.h"
#include "Grid.h"
#include "functions.h"

#include <cmath>
#include <iostream>

#include "constants.h"

/*______________________________________________________________________________

                              solveSuperSonic()

           Resolver por iteracao de Picard o escoamento supersonico sobre
    a placa plana.
______________________________________________________________________________*/
void solveSuperSonic( Grid *grid )
{
    // setgridvariables : ajuste das celulas
    setGridVariables( grid );	

	// ITERACAO DE PICARD
    do{
        Cell *gridCell;
        // Percorre todas as celulas
        for(gridCell = grid->firstGridCell; 
            gridCell != 0; 
            gridCell = gridCell->next)
        {
		   //resolve 1a coordenada
           gridCell->rhoAtual = (grid->deltaT) / (gridCell->faceLength) *
                              (
                                ( (gridCell->rhoIterAnterior)*(gridCell->uIterAnterior)
                                    +
                                  (gridCell->westRho)*(gridCell->westU)
                                )/2.0  
                               -( (gridCell->rhoIterAnterior)*(gridCell->uIterAnterior)
                                    +
                                  (gridCell->eastRho)*(gridCell->eastU)
                                )/2.0
                               +( (gridCell->rhoIterAnterior)*(gridCell->vIterAnterior)
                                    +
                                  (gridCell->southRho)*(gridCell->southV)
                                )/2.0  
                               -( (gridCell->rhoIterAnterior)*(gridCell->vIterAnterior)
                                    +
                                  (gridCell->northRho)*(gridCell->northV)
                                )/2.0
                              )
                              + gridCell->rhoAnterior;
		   // decodifica: densidade
		
		   //resolve 2a coordenada
		   // decodifica: u
		
		   //resolve 3a coordenada
		   // decodifica: v
	
		   //resolve 4a coordenada
		   // decodifica: e, T, p, mi, k


           //Avancar um passo na iteracao
           gridCell->rhoIterAnterior = gridCell->rhoAtual;
           gridCell->uIterAnterior = gridCell->uAtual;
           gridCell->vIterAnterior = gridCell->vAtual;
           gridCell->pIterAnterior = gridCell->pAtual;
           gridCell->TIterAnterior = gridCell->TAtual;
           gridCell->miIterAnterior = gridCell->miAtual;
           gridCell->kIterAnterior = gridCell->kAtual;
           gridCell->eIterAnterior = gridCell->eAtual;
            
        }
	// repetir se o erro nao for suficientemente pequeno (uma funcao para isso)
    }while(false);	

	//incrementar tempo
    
}

/*______________________________________________________________________________

                              initialCondition()

           Configura as variaveis na condicao inicial, ou seja, em t = 0.
______________________________________________________________________________*/
void initialCondition( Grid *grid)        
{
    Cell *gridCell;

    // Ajusta tempo para zero
    grid->tempoAtual = 0;
    
    // Ajustar todas as celulas com a configuracao inicial
    for(gridCell = grid->firstGridCell; gridCell != 0; gridCell=gridCell->next)
    {
	   // Variaveis de fluido
	   gridCell->rhoAtual = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE);
	   gridCell->rhoAnterior = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE);
	   gridCell->rhoIterAnterior = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE); 

	   gridCell->uAtual = 4.0*(VEL_SOM); // mach 4
	   gridCell->uAnterior =  4.0*(VEL_SOM); // mach 4
	   gridCell->uIterAnterior =  4.0*(VEL_SOM); // mach 4

	   gridCell->vAtual = 0; 
	   gridCell->vAnterior = 0; 
	   gridCell->vIterAnterior = 0;

	   gridCell->eAtual = R*TEMPERATURA_LIVRE/(GAMMA-1.0); // e = Cv * T
	   gridCell->eAnterior = R*TEMPERATURA_LIVRE/(GAMMA-1.0); // e = Cv * T 
	   gridCell->eIterAnterior = R*TEMPERATURA_LIVRE/(GAMMA-1.0); // e = Cv * T

	   gridCell->TAtual = TEMPERATURA_LIVRE;
	   gridCell->TAnterior = TEMPERATURA_LIVRE;
	   gridCell->TIterAnterior = TEMPERATURA_LIVRE;
	
	   gridCell->pAtual = PRESSAO_LIVRE;
	   gridCell->pAnterior = PRESSAO_LIVRE;
	   gridCell->pIterAnterior = PRESSAO_LIVRE;

	   gridCell->miAtual = MI_ZERO;
	   gridCell->miAnterior = MI_ZERO;
	   gridCell->miIterAnterior = MI_ZERO;

	   gridCell->kAtual = (MI_ZERO*GAMMA*R)/((GAMMA-1.0)*PRANDTL);
	   gridCell->kAnterior = (MI_ZERO*GAMMA*R)/((GAMMA-1.0)*PRANDTL);
	   gridCell->kIterAnterior = (MI_ZERO*GAMMA*R)/((GAMMA-1.0)*PRANDTL);
    }
}


/*______________________________________________________________________________
                            
                   FUNCTIONs set<Direction>BoundaryCellVariables
                            
    Set directional physical variables for cells belonging to the four boundaries 
    of the rectangular domain, i.e., apply the boundary conditions to those cells.
     
______________________________________________________________________________*/
void setSouthBoundaryCellVariables( Grid *grid, Cell *gridCell )
{
    // Caso especial para a ponta afiada da placa
    if ( gridCell->centerX == ( grid->sideLength )/
                                  pow(
                                        2,
                                        ((double)(gridCell->level)) + 1.0                                    
                                     )
       )
    {
        // Condicoes de fronteira para a ponta da placa
        gridCell->southRho = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE);
        gridCell->southU = 0.0;    
        gridCell->southV = 0.0;
        gridCell->southE = R*TEMPERATURA_LIVRE/(GAMMA-1.0);
        gridCell->southT = TEMPERATURA_LIVRE;
        gridCell->southP = PRESSAO_LIVRE;
        gridCell->southMi = MI_ZERO;
        gridCell->southK = (MI_ZERO*GAMMA*R)/((GAMMA-1.0)*PRANDTL);
    }
    else // Ajustar variaveis do vizinho do sul com condicoes de fronteira
    {
        gridCell->southP = 2.0*(gridCell->pIterAnterior) - (gridCell->northP); // extrapolacao linear 
        gridCell->southRho = (gridCell->southP)/(R*TEMPERATURA_PAREDE);
        gridCell->southU = 0.0;    
        gridCell->southV = 0.0;
        gridCell->southE =  R*TEMPERATURA_LIVRE/(GAMMA-1.0); // e = Cv * T
        gridCell->southT = TEMPERATURA_PAREDE;
        gridCell->southMi = MI_ZERO* (pow(
                                      (gridCell->southT) / TEMPERATURA_LIVRE,
                                      (3.0/2.0)
                                    )
                                )*(TEMPERATURA_LIVRE + 110.0)/
                                  ((gridCell->southT) + 110.0);
        gridCell->southK = ( (gridCell->southMi) * GAMMA * R ) /
                           ( (GAMMA-1.0) * PRANDTL );
    }
}

void setNorthBoundaryCellVariables( Cell *gridCell )
{
    // Ajustar variaveis do vizinho do norte com condicoes de fronteira
    gridCell->northP = PRESSAO_LIVRE;
    gridCell->northRho = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE);
    gridCell->northU =  4.0*(VEL_SOM);    
    gridCell->northV = 0.0;
    gridCell->northE = R*TEMPERATURA_PAREDE/(GAMMA-1.0);
    gridCell->northT = TEMPERATURA_LIVRE;
    gridCell->northMi = MI_ZERO;
    gridCell->northK = ( MI_ZERO * GAMMA * R ) / 
                       ( (GAMMA - 1.0) * PRANDTL );
}

//East boundary of domain corresponds to resonator wall.
void setEastBoundaryCellVariables( Cell *gridCell )
{
    // Ajustar variaveis do vizinho do leste com condicoes de fronteira
    gridCell->eastU =  2.0*(gridCell->uIterAnterior) - (gridCell->westU); // extrapolacao linear 
    gridCell->eastV =  2.0*(gridCell->vIterAnterior) - (gridCell->westV); // extrapolacao linear 
    gridCell->eastP =  2.0*(gridCell->pIterAnterior) - (gridCell->westP); // extrapolacao linear 
    gridCell->eastT =  2.0*(gridCell->TIterAnterior) - (gridCell->westT); // extrapolacao linear     
    gridCell->eastRho = (gridCell->eastP)/(R*(gridCell->eastT));   
    gridCell->eastE = R*(gridCell->eastT)/(GAMMA-1.0);   
    gridCell->eastMi = MI_ZERO* (pow(
                                      (gridCell->eastT) / TEMPERATURA_LIVRE,
                                      (3.0/2.0)
                                    )
                                )*(TEMPERATURA_LIVRE + 110.0)/
                                  ((gridCell->eastT) + 110.0);
    gridCell->eastK = ( (gridCell->eastMi) * GAMMA * R ) / 
                      ( (GAMMA-1.0) * PRANDTL );
}

//West boundary of domain corresponds to acoustic source.
void setWestBoundaryCellVariables( Cell *gridCell )
{           
    // Ajustar variaveis do vizinho do oeste com condicoes de fronteira
    gridCell->westP = PRESSAO_LIVRE;
    gridCell->westRho = PRESSAO_LIVRE/(R*TEMPERATURA_LIVRE);
    gridCell->westU =  4.0*(VEL_SOM);    
    gridCell->westV = 0.0;
    gridCell->westE = R*TEMPERATURA_PAREDE/(GAMMA-1.0);
    gridCell->westT = TEMPERATURA_LIVRE;
    gridCell->westMi = MI_ZERO;
    gridCell->westK = (MI_ZERO*GAMMA*R)/((GAMMA-1.0)*PRANDTL);
}
