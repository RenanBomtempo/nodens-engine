/* ==========================================
 * UFMG / ICEx
 * PAD Dinamica dos Fluidos Computacional
 * Grupo ALG
 * Titulo: Escoamento supersonico na placa plana
 * Ultima atualizacao: 19/11/06 23:04
 * ========================================== */
// main.cpp

//TAREFA: fazer funcoes que retornam o fluxo de uma determinada expressao
//em uma determinada face. Obs: as funcoes em flux.cpp NAO SE APLICAM,
//pois elas sao void. Precisamos de funcoes que retornam doubles para aplicar
//diretamente numa expressao, usando a mesma ideia daqueles em flux.cpp
//(que considera o refinamento e as respectivas distancias entre celulas)

//TAREFA: fazer funcao que verifica se o erro das variaveis da iteracao de
//picard esta' suficientemente pequeno.

//TAREFA: fazer funcoes e rotinas para desenhar resultados na tela
//tais como graficos de contorno (coloridos), etc. Devem ficar no render.cpp
//A ideia das cotas variaveis para identificar o maior valor ainda e' valido.

// Bibliotecas basicas
#include <gl/glut.h>
#include <gl/gl.h>
#include <stdarg.h>
#include <iostream>
#include <stdio.h>

    using std::cout;
    using std::endl;
    using std::ios;
    using std::cin;

// Arquivos do meu projeto 
#include "Grid.h"                             
#include "functions.h"
#include "constants.h"

// Variaveis globais de configuracao em tempo real
float escala = 4;
bool peano = false,  
     pausa = true;

int contador = 0;

// Menus e submenus acessaveis pelo mouse
static int menuprincipal, 
           submenu1,
           submenu2, 
           opcao,
           win;

// Malha principal do programa
Grid *grade;

/* ----------------------------------------
     Alterar opcoes do menu
------------------------------------------- */
void opcoes(void){
    switch (opcao){

        // Pausar a simulacao
        case (8):
            pausa = !pausa;
            opcao = -1;
        break;

        // Iniciar a simulacao
        case (9):
            initialCondition(grade);
            pausa = false;
            opcao = -1;
        break;
     
        default:
        break;
    }
}    

void Teclado(unsigned char tecla, int x, int y)
{
switch (tecla)
  {
    // Ajustando o zoom + pelo teclado
    case '=':
    case '+':
      escala += 0.2;
    break;
    // Ajustando o zoom - pelo teclado
    case '-':
    case '_':
      if (escala > 0.2)
         escala -= 0.2;
    break;

    // Visualizar a curva de Peano
    case 'p':
    case 'P':
      peano = !peano;
    break;

    // Pausar/Iniciar simulacao
    case 'Z':
    case 'z':
      pausa = (!pausa);
    break;

    // ESC sai do programa
    case 27:
    exit(0);

    default:
    break;
  }
}

// Verifica qual opcao do menu foi recebida
void menu(int value){
    if(value == 0){
        exit(0);
    }
    else{
        opcao = value;
    }
}


/* -----------------------------
     Menu acessavel pelo mouse
-------------------------------- */

void createMenu(void){

  // Cria um submenu
  submenu1 = glutCreateMenu(menu);

  // Adiciona opcoes
  glutAddMenuEntry("Opcao 1.1", 11);
  glutAddMenuEntry("Opcao 1.2", 12);

  // Cria um submenu
  submenu2 = glutCreateMenu(menu);

  // Adiciona opcoes
  glutAddMenuEntry("Opcao 2.1", 21);
  glutAddMenuEntry("Opcao 2.2", 22);

  // Menu principal
  menuprincipal = glutCreateMenu(menu);

  glutAddSubMenu("Primeiro", submenu1);
  glutAddSubMenu("Segundo", submenu2);

  glutAddMenuEntry("Iniciar", 9);
  glutAddMenuEntry("Pausar", 8);
  glutAddMenuEntry("Sair", 0);

  // O menu responde ao botao direito do mouse
  glutAttachMenu(GLUT_RIGHT_BUTTON);

}

/* 
-------------------------------------------------------------
MEU DISPLAY: onde ser� pintado e executado funcoes principais
-------------------------------------------------------------
*/
void myDisplay(void)
{
    // Prepara OpenGL para lidar com os modelos 3D
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    gluLookAt(0,0,0,0,0,-100,0,1,0);
        
    // Ajusta o zoom
    glScalef(escala,escala,1.0);
    
    // Chama as opcoes de menu    
    opcoes();

    /* Procede os calculos */
    if (!pausa)
    {                                   
      // Aqui entra as funcoes para resolver o Navier-Stokes
      solveSuperSonic( grade );
    }

    //setGridVariables( grade ); // SO' PARA TESTE !!!

    /* Plota a curva de Peano no plano XY */
    if (peano)
      grade->drawPeanoCurve(2,false);
    
    /* Plota as funcoes */
    desenharMalha(grade);
    desenharValores(grade);

    /* Desenha enfeites */
    desenharPlacaPlana();

    /* Manda a saida de graficos para a tela */
    glutSwapBuffers();
} 


/*
========================================================================
      PARTE PRINCIPAL DO PROGRAMA
========================================================================
*/
int main(int argc, char** argv)
{  
   // Iniciar o GLUT (interface do OpenGL)
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutInitWindowSize(LARGURA_TELA,ALTURA_TELA);
   glutCreateWindow("Escoamento supersonico");

   // Cor de fundo
   glClearColor(1.0,1.0,1.0,1.0); // Branco

   // Ajustes iniciais do OpenGL
   glEnable(GL_DEPTH_TEST);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-LARGURA_TELA/1,LARGURA_TELA/1,
           -ALTURA_TELA/1,ALTURA_TELA/1,
           -200,200);
   gluLookAt(0,0,0,0,0,-10,0,1,0);                 

   // Inicia grade
   grade = new Grid;
   grade->initializeGrid( false );
   refineGrid(grade,3,0.0,false);
   initialCondition(grade);

   // Entrada de interface
   glutDisplayFunc(myDisplay);
   glutKeyboardFunc(Teclado);
   createMenu();
    
   // My Display
   glutIdleFunc(myDisplay);

   glutMainLoop();
	
   return(0); 
}
