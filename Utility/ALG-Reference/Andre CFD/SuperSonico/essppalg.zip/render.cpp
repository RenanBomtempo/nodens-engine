/* -------------------------------------------------------------------
 *   render.cpp: funcoes para desenhar os graficos finais na tela
 *
 * ------------------------------------------------------------------- */

#include "functions.h"
#include <gl/glut.h>
#include <gl/gl.h>

#include <cmath>

#include "constants.h"

/* ----------------------------------------------
    Desenha a malha com suas celulas
------------------------------------------------ */
void desenharMalha(Grid *PgridDada)
{
   Cell *gridCell;

    // Percorre todas as celulas
    for(gridCell = PgridDada->firstGridCell; 
        gridCell != 0; 
        gridCell = gridCell->next)
    {  
        // ---------------- Desenha malha ---------------------
        // Desenha bordas das celulas no dominio
        glColor3f(0.8f,0.0f,0.0f);  // Preto

        // PREENCHER CELULAS DA ESQUERDA FRONTEIRA
        /*if( gridCell->centerX == (PgridDada->sideLength)/(pow(2,((double)(gridCell->level))+1.0)) )
        {
            glBegin(GL_QUADS);       
                glVertex3d(LARGURA_MALHA*(gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength)-(LARGURA_MALHA/2),
                           ALTURA_MALHA*(gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength)-(ALTURA_MALHA/2),
                           0);
                glVertex3d(LARGURA_MALHA*(gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength)-(LARGURA_MALHA/2),
                           ALTURA_MALHA*(gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength)-(ALTURA_MALHA/2),
                           0);
                glVertex3d(LARGURA_MALHA*(gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength)-(LARGURA_MALHA/2),
                           ALTURA_MALHA*(gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength)-(ALTURA_MALHA/2),
                           0);
                glVertex3d(LARGURA_MALHA*(gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength)-(LARGURA_MALHA/2),
                           ALTURA_MALHA*(gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength)-(ALTURA_MALHA/2),
                           0);
            glEnd();
        }*/    
         glColor3f(0.0f,0.0f,0.0f);  // Preto
        drawLine((gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength),
                 (gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength), 
                 0,
                    (gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength),
                    (gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength),
                    0);

        drawLine((gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength),
                 (gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength), 
                 0,
                    (gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength),
                    (gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength),
                    0);

        drawLine((gridCell->centerX+gridCell->halfFaceLength)/(PgridDada->sideLength),
                 (gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength), 
                 0,
                    (gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength),
                    (gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength),
                    0);

        drawLine((gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength),
                 (gridCell->centerY-gridCell->halfFaceLength)/(PgridDada->sideLength), 
                 0,
                    (gridCell->centerX-gridCell->halfFaceLength)/(PgridDada->sideLength),
                    (gridCell->centerY+gridCell->halfFaceLength)/(PgridDada->sideLength),
                    0); 
   }
}

/* -----------------------------------------------
    Desenha a placa plana na borda sul (enfeite)
-------------------------------------------------- */
void desenharPlacaPlana()
{
    // Ajustar para cinza
    glColor3f(0.5f,0.5f,0.5f);
    
    // Desenhar placa plana na forma de poligono
    glBegin(GL_POLYGON);       
        glVertex3d(-(LARGURA_MALHA/2),
                   -(ALTURA_MALHA/2),
                   0);
        glVertex3d(-0.75*(LARGURA_MALHA/2),
                   -1.1*(ALTURA_MALHA/2),
                   0);
        glVertex3d((LARGURA_MALHA/2),
                   -1.1*(ALTURA_MALHA/2),
                   0);
        glVertex3d((LARGURA_MALHA/2),
                   -(ALTURA_MALHA/2),
                   0);
    glEnd();
}

/* -----------------------------------------------
    Desenha valores de uma variavel em cada celula
-------------------------------------------------- */
void desenharValores(Grid *grid)
{
    Cell *gridCell;

    char str[5];

    glColor3f(0.0f,0.0f,0.5f);
    // Percorre todas as celulas
    for(gridCell = grid->firstGridCell; 
        gridCell != 0; 
        gridCell = gridCell->next)
    {
        // Preencher string com valores
        sprintf(str, "%1.1f", gridCell->rhoAtual);  //imprimir rho

	    drawString(str,GLUT_BITMAP_HELVETICA_10,
                    LARGURA_MALHA*gridCell->centerX/(grid->sideLength)-(LARGURA_MALHA/2.0),
                    LARGURA_MALHA*gridCell->centerY/(grid->sideLength)-(LARGURA_MALHA/2.0),
                    0);
    }
}
