//erros.h
// Contem definicoes de codigos para representar erros

//Criado por Andre STALTZ dia 31/03/07
  
#ifndef ERROS_H
#define ERROS_H

    // Erros genericos ==================================================================
    #define SUCESSO                     0
    #define ERRO_FLUXO_EXECUCAO         1  // erro de programacao, pois o fluxo
                                           // de execucao nao deveria atingi'-lo
    #define INSUCESSO                   2

    // Erros de malha ===================================================================
    #define ERRO_MALHA_VAZIA            3
    #define ERRO_CELULA_INEXISTENTE     4

    // Erros de celula e resolucao do problema ==========================================
    #define ERRO_ID_VAR_INEXISTENTE     5
    #define ERRO_ELEMENT_NULO           6

    // Macros para impressoes de erro no terminal =======================================
    #ifndef IOSTREAM__INCLUIDO
    #define IOSTREAM__INCLUIDO
#include <iostream>
            using std::cout;
            using std::endl;
            using std::ios;
            using std::cin;
    #endif // IOSTREAM_INCLUIDO

    #define IMPRIMIR_ERRO_FLUXO_EXECUCAO()  (cout << "Erro: fluxo de execucao atingiu um local inesperado." << endl)
    
    #define IMPRIMIR_ERRO_MALHA_VAZIA()  (cout << "Erro: a malha esta' vazia, ou seja, nao possui celulas." << endl)
    
    #define IMPRIMIR_ERRO_FRONTEIRA_DE_CELULA_INEXISTENTE() (cout << "Erro: uma condicao de fronteira foi solicitada para uma celula inexistente!" << endl)

    #define IMPRIMIR_ERRO_FRONTEIRA_DIRECAO_INEXISTENTE() (cout << "Erro: uma condicao de fronteira foi solicitada para uma direcao inexistente!" << endl)

    #define IMPRIMIR_ERRO_FRONTEIRA_ID_VARIAVEL_INEXISTENTE() (cout << "Erro: uma condicao de fronteira foi solicitada para uma id de variavel inexistente!" << endl)

    #define IMPRIMIR_ERRO_CELULA_INEXISTENTE() (cout << "Erro: uma celula foi solicitada mas ela nao existe (ou aponta para o vazio)!" << endl)
    
    #define IMPRIMIR_ERRO_ID_VARIAVEL_INEXISTENTE() (cout << "Erro: foi solicitado uma id de variavel inexistente!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DUDX() (cout << "Erro: foi solicitado calculo de du/dx em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DUDY() (cout << "Erro: foi solicitado calculo de du/dy em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DVDX() (cout << "Erro: foi solicitado calculo de dv/dx em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DVDY() (cout << "Erro: foi solicitado calculo de dv/dy em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DTDX() (cout << "Erro: foi solicitado calculo de dT/dx em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_FACE_INVALIDA_DTDY() (cout << "Erro: foi solicitado calculo de dT/dy em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_VAR_NAO_IMPLEMENTADA() (cout << "Erro: essa variavel ainda nao foi implementada na funcao obtemVariaveisVizinhas()" << endl) 
    
    #define IMPRIMIR_ERRO_FACE_INVALIDA() (cout << "Erro: foi solicitado calculo em uma face invalida!" << endl)

    #define IMPRIMIR_ERRO_DIRECAO_INVALIDA() (cout << "Erro: foi solicitada uma direcao invalida!" << endl)

    #define IMPRIMIR_ERRO_ELEMENT_NULO() (cout << "Erro: firstElement e' nulo, nao ha' como acessar seus campos!" << endl)

    #define IMPRIMIR_ID_CICLO_INEXISTENTE() (cout << "Erro: foi dado um identificador de ciclo (do algoritmo SIMPLEC) inexistente!" << endl)
        

#endif // ERROS_H
