/*
 * constants.h
 *
 *  Created on: 21/07/2011
 *      Author: sachetto
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define UM2_TO_CM2 0.00000001
#define UM3_TO_CM3 10e-12

#endif /* CONSTANTS_H_ */
